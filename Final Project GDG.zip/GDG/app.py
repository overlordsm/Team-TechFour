import streamlit as st
import os
import google.generativeai as genai
from bs4 import BeautifulSoup
from pypdf import PdfReader
import easyocr
import requests
import time
from gtts import gTTS

# --- 1. CONFIGURATION ---
st.set_page_config(page_title="GIETU Nexus (Final)", page_icon="🏛️", layout="wide")

# !!! PASTE YOUR API KEY HERE !!!
os.environ["GOOGLE_API_KEY"] = "AIzaSyCFRCVbMcZos40e_PuWbwodUBfYAXK4RiI" 
genai.configure(api_key=os.environ["GOOGLE_API_KEY"])

TARGET_URL = "https://www.giet.edu/happenings/notices/"
NOTICES_DIR = "notices_vault"

# --- 2. AUTO-DETECT MODEL ---
def get_working_model():
    """Finds the best available model automatically."""
    try:
        models = [m.name for m in genai.list_models() if 'generateContent' in m.supported_generation_methods]
        # Prefer flash for speed
        for m in models:
            if 'flash' in m: return m
        # Fallback to Pro
        for m in models:
            if 'pro' in m: return m
        return "models/gemini-pro"
    except: return "gemini-pro"

# --- 3. UI STYLING ---
st.markdown("""
<style>
    .main { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: #e2e8f0; }
    .stTextInput > div > div > input { background-color: rgba(255, 255, 255, 0.1); color: white; border: 1px solid #475569; }
</style>
""", unsafe_allow_html=True)

# --- 4. LOGIN ---
if 'authenticated' not in st.session_state:
    st.session_state['authenticated'] = False

if not st.session_state['authenticated']:
    c = st.container()
    c.title("GIETU Nexus 🚀")
    with c.form("login"):
        if st.form_submit_button("Enter Vault"):
            st.session_state['authenticated'] = True
            st.rerun()
    st.stop()

# --- 5. ENGINES ---
@st.cache_resource
def load_ocr():
    return easyocr.Reader(['en'], gpu=False)

ocr_reader = load_ocr()

def text_to_speech(text):
    try:
        short_text = text[:300]
        tts = gTTS(text=short_text, lang='en')
        filename = f"audio_{int(time.time())}.mp3"
        tts.save(filename)
        return filename
    except: return None

def scrape_giet():
    if not os.path.exists(NOTICES_DIR): os.makedirs(NOTICES_DIR)
    try:
        r = requests.get(TARGET_URL, headers={'User-Agent': 'Mozilla/5.0'}, timeout=5)
        soup = BeautifulSoup(r.content, 'html.parser')
        pdf_links = [a['href'] for a in soup.find_all('a', href=True) if a['href'].lower().endswith('.pdf')]
        
        new_files = []
        for url in pdf_links[:3]: 
            filename = url.split('/')[-1]
            path = os.path.join(NOTICES_DIR, filename)
            if not os.path.exists(path):
                f_r = requests.get(url)
                with open(path, 'wb') as f: f.write(f_r.content)
                new_files.append(filename)
        return new_files
    except: return []

def process_vault_fast():
    combined_text = ""
    file_list = []
    
    # LOOP THROUGH EVERY SINGLE FILE
    all_files = [f for f in os.listdir(NOTICES_DIR) if f.endswith(".pdf")]
    
    progress_bar = st.progress(0)
    
    for i, f in enumerate(all_files):
        path = os.path.join(NOTICES_DIR, f)
        try:
            reader = PdfReader(path)
            text = ""
            
            # Read first 15 pages of EACH file
            for page in reader.pages[:15]: 
                text += page.extract_text() or ""
            
            # Use OCR if text is missing
            if len(text.strip()) < 50:
                result = ocr_reader.readtext(path, detail=0, paragraph=True) 
                text = " ".join(result)
            
            if text:
                combined_text += f"\n--- START OF FILE: {f} ---\n{text}\n--- END OF FILE ---\n"
                file_list.append(f)
        except: pass
        
        progress_bar.progress((i + 1) / len(all_files))
        
    return combined_text, file_list

# --- 6. DASHBOARD ---
with st.sidebar:
    st.title("Nexus Control")
    if st.button("🔄 Sync & Read Everything"):
        with st.status("Reading All Files...", expanded=True):
            st.write("🌐 Checking Website...")
            scrape_giet()
            
            st.write(f"👁️ Scanning Local Folder ({len(os.listdir(NOTICES_DIR))} files)...")
            text, files = process_vault_fast()
            st.session_state.vault_text = text
            st.session_state.files = files
            
            st.success("Vault Updated!")
            
    st.markdown("### 📂 Loaded Files:")
    if "files" in st.session_state:
        for f in st.session_state.files:
            st.code(f)
    else:
        st.warning("No files loaded yet.")

# --- 7. MAIN CHAT ---
st.title("GIETU VisionSearch ⚡")
st.caption("Scanning All Files | Auto-Fallback Enabled")



if "messages" not in st.session_state:
    st.session_state.messages = [{"role": "assistant", "content": "I have read all your files. Ask me anything."}]

for msg in st.session_state.messages:
    with st.chat_message(msg["role"], avatar="🤖" if msg["role"] == "assistant" else "🧑‍🎓"):
        st.markdown(msg["content"])

if prompt := st.chat_input("What is 3NF?"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user", avatar="🧑‍🎓"):
        st.markdown(prompt)

    with st.chat_message("assistant", avatar="🤖"):
        if "vault_text" not in st.session_state:
            st.error("⚠️ Please click 'Sync & Read Everything' first!")
            st.stop()
        
        with st.spinner("⚡ Analyzing..."):
            try:
                model_name = get_working_model()
                model = genai.GenerativeModel(model_name)
                
                safe_context = st.session_state.vault_text
                
                # --- THE MAGIC PROMPT ---
                # This prompt forces the AI to answer even if the file is incomplete.
                full_prompt = f"""
                You are a university assistant.
                
                --- BEGIN CONTEXT FROM FILES ---
                {safe_context}
                --- END CONTEXT ---
                
                QUESTION: {prompt}
                
                INSTRUCTIONS:
                1. FIRST, check the CONTEXT above. If the answer is there, use it.
                2. CRITICAL: If the answer is missing from the context (e.g., if asking about 3NF but the notes only cover 1NF), YOU MUST ANSWER USING YOUR OWN KNOWLEDGE.
                3. Do NOT say "I couldn't find it". Instead say: "While the uploaded notices focus on basics, standard 3NF is defined as..."
                4. Give a clear, academic answer suitable for a CS student.
                """
                
                response = model.generate_content(full_prompt)
                ans = response.text
                
                st.markdown(ans)
                st.session_state.messages.append({"role": "assistant", "content": ans})
                
                with st.expander("🕵️ Debug: Files Checked"):
                    st.text(f"Read {len(st.session_state.files)} files.")
                    
                audio = text_to_speech(ans)
                if audio: st.audio(audio)
            except Exception as e: st.error(f"Error: {e}")